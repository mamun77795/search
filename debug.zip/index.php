<?php

// load the bootstrap file
require __DIR__ . '/src/bootstrap.php';
// whoa! that was quick!
$app->run();
