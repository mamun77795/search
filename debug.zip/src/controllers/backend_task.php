<?php

use spark\drivers\Nav\Pagination;
Pagination::setTranslations([
    'next' => svg_icon('arrow-right'),
    'prev' => svg_icon('arrow-left'),
]);
