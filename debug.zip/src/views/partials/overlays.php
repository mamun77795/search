<div id="global-ajax-overlay"></div>
